import React from 'react'

const Product5 = () => {
  return (
    <div>Product5</div>
  )
}

export default Product5