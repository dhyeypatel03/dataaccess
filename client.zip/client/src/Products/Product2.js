import React, { useState, useEffect } from 'react';
import './Product2.css'; // Import your CSS file
import Layout from '../components/Layout/Layout'
const Product2 = () => {
  const [phoneData, setPhoneData] = useState([]);
  const [selectedPhone, setSelectedPhone] = useState(null);
  const selectedPhoneId = '65f6cb59b43e8f16d15b4882'; // Replace 'your_selected_id' with the _id of the phone you want to display

  useEffect(() => {
    fetch(`${process.env.REACT_APP_API}/api/v1/phones`)
      .then(response => {
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        return response.json();
      })
      .then(data => {
        console.log('Data received:', data); // Check the received data
        setPhoneData(data);

        // Find the phone with the selected ID
        const foundPhone = data.find(phone => phone._id === selectedPhoneId);
        setSelectedPhone(foundPhone);
      })
      .catch(error => {
        console.error('Error fetching phone data:', error);
        // Additional error handling, such as setting a flag for UI feedback
      });
  }, [selectedPhoneId]); // Include selectedPhoneId in the dependency array to re-fetch data when the ID changes
  
  if (!selectedPhone) {
    return <div>Loading...</div>;
  }

  return (
    <Layout>
    <div className="product-container">
      {/* <h1>OnePlus 11R 5G</h1> */}
      <img src='/images/oneplus11r.jpg' alt="Phone" className="phone-image" />
      <div className="phone-details">
        <h2>{selectedPhone.name}</h2>
        <p>{selectedPhone.description}</p>
        <div className="ratings-price">
          <p>Ratings: {selectedPhone.ratings}</p>
          <p>Price: {selectedPhone.price}</p>
        </div>
        <div className="buttons">
          <button className="amazon-button" onClick={() => window.open("https://amzn.eu/d/iQUEyjR", '_blank')}>Buy on Amazon</button>
          <button className="flipkart-button" onClick={() => window.open("http://dl.flipkart.com/dl/oneplus-11r-5g-sonic-black-128-gb/p/itmd8344a066fd54?pid=MOBGQ9PX4FCMG5MP&cmpid=product.share.pp&lid=LSTMOBGQ9PX4FCMG5MPG1IT42", '_blank')}>Buy on Flipkart</button>
        </div>
      </div>
    </div>
    </Layout>
  );
}

export default Product2;
