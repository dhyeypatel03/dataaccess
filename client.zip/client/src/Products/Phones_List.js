// Products_List.js
const phones = [
    {
      id: 1,
      name: "OnePlus 11R 5G",
      description: "Sonic Black, 8GB RAM, 128GB Storage",
      imageUrl: '/images/oneplus11r.jpg',
    },
    {
      id: 2,
      name: "Product 2",
      description: "Description for Product 2",
      imageUrl: "/images/iphone15promax.jpg",
    },
    {
      id: 3,
      name: "Product 3",
      description: "Description for Product 3",
      imageUrl: "/images/samsung.jpg",
    },
    {
      id: 4,
      name: "Product 4",
      description: "Description for Product 4",
      imageUrl: "/images/oneplus11r.jpg",
    },
    {
      id: 5,
      name: "Product 5",
      description: "Description for Product 5",
      imageUrl: "/images/oneplus11r.jpg",
    }
    // Add more products as needed
  ];
  
  
  
  export default phones  ;
  