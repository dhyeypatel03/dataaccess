const watches = [
    {
      id: 1,
      name: "Product 1",
      description: "Description for Product 1",
      imageUrl: '/images/titan1.jpg',
    },
    {
      id: 2,
      name: "Product 2",
      description: "Description for Product 2",
      imageUrl: "/images/titan2.jpg",
    },
    {
      id: 3,
      name: "Product 3",
      description: "Description for Product 3",
      imageUrl: "/images/titan3.jpg",
    },
    {
      id: 4,
      name: "Product 4",
      description: "Description for Product 4",
      imageUrl: "/images/titan1.jpg",
    },
    {
      id: 5,
      name: "Product 5",
      description: "Description for Product 5",
      imageUrl: "/images/titan3.jpg",
    }
    // Add more products as needed
  ];
  export default watches;