import React from 'react'

const Product4 = () => {
  return (
    <div>Product4</div>
  )
}

export default Product4