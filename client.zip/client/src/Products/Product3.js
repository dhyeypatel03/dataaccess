import React from 'react'

const Product3 = () => {
  return (
    <div>Product3</div>
  )
}

export default Product3