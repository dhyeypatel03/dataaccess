import React from 'react'
import Layout from '../components/Layout/Layout'
import "../styles/Homepage.css";
import { Link } from 'react-router-dom';
import phones  from '../Products/Phones_List';
import Samsung from '../Products/Samsung_list';
import Bluetooth_devices from '../Products/Bluetooth_devices';

const Homepage = () => {

  return (
    <Layout>
      <h2>Welcome to PRICESNAP</h2>
      
      <div className='maindiv'>
        <h3>Category: iPhones</h3>
      <div className="product-grid">
        {phones.map(product => (
          <div key={product.id} className="product-card">
            <img src={product.imageUrl} alt={product.name} />
            <h3>{product.name}</h3>
            <p>{product.description}</p>
            <Link to={`/Product${product.id}`}>View Details</Link>
          </div>
        ))}
      </div>
      <h3>Category:Samsung Phones</h3>
      <div className="product-grid">
        {Samsung.map(product => (
          <div key={product.id} className="product-card">
            <img src={product.imageUrl} alt={product.name} />
            <h3>{product.name}</h3>
            <p>{product.description}</p>
            <Link to={`/Product${product.id}`}>View Details</Link>
          </div>
          
        ))}
      </div>
      <h3>Category:Bluetooth Earbuds and Speakers</h3>
      <div className="product-grid">
        {Bluetooth_devices.map(product => (
          <div key={product.id} className="product-card">
            <img src={product.imageUrl} alt={product.name} />
            <h3>{product.name}</h3>
            <p>{product.description}</p>
            <Link to={`/Product${product.id}`}>View Details</Link>
          </div>
          
        ))}
      </div>
      </div>
    </Layout>
  );
};

export default Homepage