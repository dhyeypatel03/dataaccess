// Products_List.js
const Bluetooth_devices = [
    {
      id: 9,
      name: "OnePlus Nord Buds 2-Thunder Gray ",
      description: "Base Price:- ₹3,299",
      imageUrl: '/images/oneplusnordbuds2.jpg',
    },
    {
      id: 10,
      name: "OnePlus Nord Buds 2r-Deep Grey",
      description: "Base Price:- ₹2,299",
      imageUrl: "/images/oneplus_nordbuds2r.jpg",
    },
    {
      id: 11,
      name: "OnePlus Buds Z2-Pearl White",
      description: "Base Price:- ₹5,999",
      imageUrl: "/images/oneplus_budsZ2.jpg",
    },
    {
      id: 12,
      name: "boAt Stone 352 Bluetooth Speaker Green Fury - Hulk Edition ",
      description: "Base Price:- ₹3490",
      imageUrl: "/images/boatstone352_greenfury.jpg",
    },
    {
      id: 13,
      name: "boAt Stone 650-Black ",
      description: "Base Price:- ₹4,990",
      imageUrl: "/images/boatstone650.jpg",
    }
    // Add more products as needed
  ];
  
  
  
  export default Bluetooth_devices  ;
  