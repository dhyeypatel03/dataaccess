// Products_List.js
const phones = [
    {
      id: 1,
      name: "Apple iPhone 15 Pro Max ",
      description: "Base Price:- ₹1,59,900",
      imageUrl: '/images/iphone15promaxBlack.jpg',
    },
    {
      id: 2,
      name: "Apple iPhone 15 Pro",
      description: "Base Price:- ₹79,900",
      imageUrl: "/images/iphone15problue1tb.jpg",
    },
    {
      id: 3,
      name: "Apple iPhone 15 (128 GB) - Black ",
      description: "Base Price:- ₹79,900",
      imageUrl: "/images/iphone15black128gb.jpg",
    },
    {
      id: 4,
      name: "Apple iPhone 15 Plus (128 GB) - Black ",
      description: "Base Price:- ₹89,900",
      imageUrl: "/images/iphone15plusblack128gb.jpg",
    },
    {
      id: 5,
      name: "Apple iPhone 13 (128GB) - Blue ",
      description: "Base Price:- ₹59,900",
      imageUrl: "/images/iphone13starlight128gb.jpg",
    }
    // Add more products as needed
  ];
  
  
  
  export default phones  ;
  