const Samsung = [
    {
      id: 6,
      name: "Samsung Galaxy S24 Ultra 5G AI Smartphone ",
      description: "Base Price:- ₹1,44,999",
      imageUrl: '/images/Samsung_galaxyS24ultra.jpg',
    },
    {
      id: 7,
      name: "Samsung Galaxy S24 Ultra 5G AI Smartphone ",
      description: "Base Price:- ₹1,34,999",
      imageUrl: "/images/Samsung24ultraviolet.jpg",
    },
    {
      id: 8,
      name: "Samsung Galaxy S23 5G ",
      description: "Base Price:- ₹95,999",
      imageUrl: "/images/Samsunggalaxys23.jpg",
    }
    // {
    //   id: 9,
    //   name: "Product 4",
    //   description: "Description for Product 4",
    //   imageUrl: "/images/titan1.jpg",
    // },
    // {
    //   id: 10,
    //   name: "Product 5",
    //   description: "Description for Product 5",
    //   imageUrl: "/images/titan3.jpg",
    // }
    // Add more products as needed
  ];
  export default Samsung;